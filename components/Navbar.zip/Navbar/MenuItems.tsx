export const MenuItems = [
  {
    title: "Home",
    url: "/",
    cName: "nav-item",
  },
  {
    title: "About",
    url: "/about",
    cName: "nav-item",
  },
  // {
  //   title: "Portfolio",
  //   url: "/projects",
  //   cName: "nav-item",
  // },
  // {
  //   title: "Services",
  //   url: "/services",
  //   cName: "nav-item",
  // },
  // {
  //   title: "Contact",
  //   url: "/contact",
  //   cName: "nav-item",
  // },
];
